#pragma once
#include <iostream>
#include <windows.h>
#include "Func.h"
using namespace std;

//********************************************//
//               InsertionSort			     //
//MIN->MAX
void Insertion1(int* a, int n, int speed, int debug) {
    int i, j, x;
    for (i = 1; i < n; i++) {
        x = a[i];
        Print_Array(a, n, speed, debug, "Insertion Sort", 1, i);
        for (j = i - 1; (j >= 0) and (x < a[j]); j--) {//Check if a[i] can be inserted
            a[j + 1] = a[j];//Move element to the back
            Print_Array(a, n, speed, debug, "Insertion Sort",1,j);//Print to simulate
        }
        a[j + 1] = x;//Insert x to the right position
        Print_Array(a, n, speed, debug, "Insertion Sort",1,j);//Print to simulate
    }
    Print_Array(a, n, speed, debug, "Insertion Sort", 1);
}

//MAX->MIN
void Insertion2(int* a, int n, int speed, int debug) {
    int i, j, x;
    for (i = 1; i < n; i++) {
        x = a[i];
        Print_Array(a, n, speed, debug, "Insertion Sort", 1, i);
        for (j = i - 1; (j >= 0) and (x > a[j]); j--) {//Check if a[i] can be inserted
            a[j + 1] = a[j];//Move element to the back
            Print_Array(a, n, speed, debug, "Insertion Sort",2,j);//Print to simulate
        }
        a[j + 1] = x;//Insert x to the right position
        Print_Array(a, n, speed, debug, "Insertion Sort",2,j);//Print to simulate
    }
    Print_Array(a, n, speed, debug, "Insertion Sort", 2);
}
//********************************************//









//********************************************//
//             Binary Insertion Sort		 //
int binarySearch0(int a[], int item, int low, int high)//Used for MIN->MAX
{
    if (high <= low)
        return (item > a[low]) ?
        (low + 1) : low;

    int mid = (low + high) / 2;

    if (item == a[mid])
        return mid + 1;

    if (item > a[mid])
        return binarySearch0(a, item,
            mid + 1, high);
    return binarySearch0(a, item, low,
        mid - 1);
}

int binarySearch1(int a[], int item, int low, int high)//Used for MAX->MIN
{
    if (high <= low)
        return (item < a[low]) ?
        (low + 1) : low;

    int mid = (low + high) / 2;

    if (item == a[mid])
        return mid + 1;

    if (item < a[mid])
        return binarySearch1(a, item,
            mid + 1, high);
    return binarySearch1(a, item, low,
        mid - 1);
}

// Function to sort an array a[] of size 'n'
void BinaryInsertion(int* a, int n, int o, int speed, int debug)
{
    int i, loc, j, selected;

    for (i = 1; i < n; ++i)
    {
        j = i - 1;
        selected = a[i];
        Print_Array(a, n, speed, debug, "Binary Insertion Sort", o,i);
        // find location where selected sould be inseretd
        if (o == 1) {//Choose the right direction search
            loc = binarySearch0(a, selected, 0, j);
        }
        else {
            loc = binarySearch1(a, selected, 0, j);
        }

        // Move all elements after location to create space
        while (j >= loc)
        {
            Print_Array(a, n, speed, debug, "Binary Insertion Sort", o, j+1);
            a[j + 1] = a[j];
            j--;
            Print_Array(a, n, speed, debug, "Binary Insertion Sort", o,j+1);//Print to simulate
        }
        a[j + 1] = selected;
        Print_Array(a, n, speed, debug, "Binary Insertion Sort", o, j + 1);
    }
    Print_Array(a, n, speed, debug, "Binary Insertion Sort", o);
}
//********************************************//








//********************************************//
//                Bubble Sort		         //
//MIN->MAX
void Bubble1(int *arr, int n, int speed, int debug)
{
    int i, j;
    bool haveSwap = false;
    for (i = 0; i < n - 1; i++) {
        // i elements have been sorted
        haveSwap = false;
        for (j = 0; j < n - i - 1; j++) {
            Print_Array(arr, n, speed, debug, "Bubble Sort", 1, j, j + 1);
            if (arr[j] > arr[j + 1]) {
                swap(arr[j], arr[j + 1]);
                Print_Array(arr, n, speed, debug, "Bubble Sort", 1,j+1,j);//Print to simulate
                haveSwap = true; //Check if swap was made
            }
        }
        //If swap wasn't made -> array sorted, end loop
        if (haveSwap == false) {
            break;
        }
    }
    Print_Array(arr, n, speed, debug, "Bubble Sort", 1);
}

//MAX->MIN
void Bubble2(int *arr, int n, int speed, int debug)
{
    int i, j;
    bool haveSwap = false;
    for (i = 0; i < n - 1; i++) {
        // i elements have been sorted
        haveSwap = false;
        for (j = 0; j < n - i - 1; j++) {
            Print_Array(arr, n, speed, debug, "Bubble Sort", 2, j, j + 1);
            if (arr[j] < arr[j + 1]) {
                swap(arr[j], arr[j + 1]);
                Print_Array(arr, n, speed, debug, "Bubble Sort", 2,j+1,j);//Print to simulate
                haveSwap = true; //Check if swap was made
            }
        }
        //If swap wasn't made -> array sorted, end loop
        if (haveSwap == false) {
            break;
        }
    }
    Print_Array(arr, n, speed, debug, "Bubble Sort", 2);
}
//********************************************//








//********************************************//
//               Selection Sort		         //
//MIN->MAX
void Selection1(int *a, int n, int s, int d) {//s is speed, d is debug
    int m;
    int i, j;
    int temp;
    for (i = 0; i < n; i++)
    {
        m = i;
        for (j = i + 1; j < n; j++)
        {
            Print_Array(a, n, s, d, "Selection Sort", 1,i,m,j);
            if (a[j] < a[m]) {
                m = j;
            }
        }
        Print_Array(a, n, s, d, "Selection Sort", 1, i, m);
        temp = a[i];
        a[i] = a[m];
        a[m] = temp;
        Print_Array(a, n, s, d, "Selection Sort",1,m,i);//Print to simulate
    }
    Print_Array(a, n, s, d, "Selection Sort",1);
}

//MAX->MIN
void Selection2(int *a, int n, int s, int d) {
    int m;
    int i, j;
    int temp;
    for (i = 0; i < n; i++)
    {
        m = i;
        for (j = i + 1; j < n; j++)
        {
            Print_Array(a, n, s, d, "Selection Sort", 2, i, m,j);
            if (a[j] > a[m]) {
                m = j;
            }
        }
        Print_Array(a, n, s, d, "Selection Sort", 2, i, m);
        temp = a[i];
        a[i] = a[m];
        a[m] = temp;
        Print_Array(a, n, s, d, "Selection Sort",2,m,i);//Print to simulate
    }
    Print_Array(a, n, s, d, "Selection Sort", 2);
}
//********************************************//








//********************************************//
//               Interchange Sort		     //
//MIN->MAX
void Interchange1(int *a, int n, int s, int d) {
    int i, j;
    int temp;
    for (i = 0; i < n; i++)
    {
        for (j = i + 1; j < n; j++)
        {
            Print_Array(a, n, s, d, "Interchange Sort", 1,i,j);
            if (a[i] > a[j]) {
                temp = a[i];
                a[i] = a[j];
                a[j] = temp;
                Print_Array(a, n, s, d, "Interchange Sort", 1, j, i);
            }
        }
    }
    Print_Array(a, n, s, d, "Interchange Sort", 1);//Print to simulate
}

//MAX->MIN
void Interchange2(int* a, int n, int s, int d) {
    int i, j;
    int temp;
    for (i = 0; i < n; i++)
    {
        for (j = i + 1; j < n; j++)
        {
            Print_Array(a, n, s, d, "Interchange Sort", 2,i,j);
            if (a[i] < a[j]) {
                temp = a[i];
                a[i] = a[j];
                a[j] = temp;
                Print_Array(a, n, s, d, "Interchange Sort", 2, j, i);
            }
        }
    }
    Print_Array(a, n, s, d, "Interchange Sort", 2);//Print to simulate
}
//********************************************//





//********************************************//
//               Shaker Sort		         //
//MIN->MAX
void Shaker1(int *a, int n, int speed, int debug)
{
    int i;
    int Left = 0;
    int Right = n - 1;
    int k = 0;
    while (Left < Right)
    {
        for (int i = Left; i < Right; i++)//Move min value to the left
        {
            Print_Array(a, n, speed, debug, "Shaker Sort", 1,i,i+1);
            if (a[i] > a[i + 1])
            {
                swap(a[i], a[i + 1]);
                k = i;
                Print_Array(a, n, speed, debug, "Shaker Sort", 1,i+1,i);
            }
        }
        Right = k;
        for (i = Right; i > Left; i--)//Move max value to the right
        {
            Print_Array(a, n, speed, debug, "Shaker Sort", 1, i, i - 1);
            if (a[i] < a[i - 1])
            {
                swap(a[i], a[i - 1]);
                k = i;
                Print_Array(a, n, speed, debug, "Shaker Sort", 1,i-1,i);
            }
        }
        Left = k;
    }
    Print_Array(a, n, speed, debug, "Shaker Sort", 1);
}

//MAX->MIN
void Shaker2(int a[], int n, int speed, int debug)
{
    int i;
    int Left = 0;
    int Right = n - 1;
    int k = 0;
    while (Left < Right)
    {
        for (int i = Left; i < Right; i++)//Move max value to the left
        {
            Print_Array(a, n, speed, debug, "Shaker Sort", 2,i,i+1);
            if (a[i] < a[i + 1])
            {
                swap(a[i], a[i + 1]);
                k = i;
                Print_Array(a, n, speed, debug, "Shaker Sort", 2,i+1,i);
            }
        }
        Right = k;
        for (i = Right; i > Left; i--)//Move min value to the left
        {
            Print_Array(a, n, speed, debug, "Shaker Sort", 2,i,i-1);
            if (a[i] > a[i - 1])
            {
                swap(a[i], a[i - 1]);
                k = i;
                Print_Array(a, n, speed, debug, "Shaker Sort", 2,i-1,i);
            }
        }
        Left = k;
    }
    Print_Array(a, n, speed, debug, "Shaker Sort", 2);
}
//********************************************//








//********************************************//
//               Shell Sort		             //
//MIN->MAX
void Shell1(int *arr, int n, int speed, int debug)
{
    // Start with a big gap, then reduce the gap
    for (int gap = n / 2; gap > 0; gap /= 2)
    {
        // Do a gapped insertion sort for this gap size.
        // The first gap elements a[0..gap-1] are already in gapped order
        // keep adding one more element until the entire array is
        // gap sorted
        for (int i = gap; i < n; i += 1)
        {
            // add a[i] to the elements that have been gap sorted
            // save a[i] in temp and make a hole at position i
            int temp = arr[i];

            // shift earlier gap-sorted elements up until the correct
            // location for a[i] is found
            int j;
            for (j = i; j >= gap && arr[j - gap] > temp; j -= gap) {
                Print_Array(arr, n, speed, debug, "Shell Sort", 1,j,j-gap);
                arr[j] = arr[j - gap];
                Print_Array(arr, n, speed, debug, "Shell Sort", 1,j,j-gap);
            }
            //  put temp (the original a[i]) in its correct location
            Print_Array(arr, n, speed, debug, "Shell Sort", 1,j,i);
            arr[j] = temp;
            Print_Array(arr, n, speed, debug, "Shell Sort", 1,j,i);
        }
    }
    Print_Array(arr, n, speed, debug, "Shell Sort", 1);
}

//MAX->MIN
void Shell2(int *arr, int n, int speed, int debug)
{
    // Start with a big gap, then reduce the gap
    for (int gap = n / 2; gap > 0; gap /= 2)
    {
        // Do a gapped insertion sort for this gap size.
        // The first gap elements a[0..gap-1] are already in gapped order
        // keep adding one more element until the entire array is
        // gap sorted
        for (int i = gap; i < n; i += 1)
        {
            // add a[i] to the elements that have been gap sorted
            // save a[i] in temp and make a hole at position i
            int temp = arr[i];

            // shift earlier gap-sorted elements up until the correct
            // location for a[i] is found
            int j;
            for (j = i; j >= gap && arr[j - gap] < temp; j -= gap) {
                Print_Array(arr, n, speed, debug, "Shell Sort", 2, j, j - gap);
                arr[j] = arr[j - gap];
                Print_Array(arr, n, speed, debug, "Shell Sort", 2,j,j-gap);
            }

            //  put temp (the original a[i]) in its correct location
            Print_Array(arr, n, speed, debug, "Shell Sort", 2, j, i);
            arr[j] = temp;
            Print_Array(arr, n, speed, debug, "Shell Sort", 2, j, i);
        }
    }
    Print_Array(arr, n, speed, debug, "Shell Sort", 2);
}
//********************************************//









//********************************************//
//               Counting Sort	             //
//MIN->MAX
void Counting(int* Array, int n, int o, int speed, int debug)
{
    int* output = new int[n]; // The output will have sorted Array array
    for (int i = 0; i < n; i++) {
        output[i] = 0;
    }
    int max = Array[0];
    int min = Array[0];

    for (int i = 1; i < n; i++)
    {
        if (Array[i] > max)
            max = Array[i]; // Maximum value in array
        else if (Array[i] < min)
            min = Array[i]; // Minimum value in array
    }

    int k = max - min + 1; // Size of count array

    int* count_array = new int[k]; // Create a count_array to store count of each individual Array value
    fill_n(count_array, k, 0); // Initialize count_array elements as zero

    for (int i = 0; i < n; i++)
        count_array[Array[i] - min]++; // Store count of each individual Array value

    /* Change count_array so that count_array now contains actual
     position of Array values in output array */
    for (int i = 1; i < k; i++)
        count_array[i] += count_array[i - 1];


    // Populate output array using count_array and Array array
    for (int i = 0; i < n; i++)
    {
        Print_Array(output, n, speed, debug, "Counting Sort", o, count_array[Array[i] - min] - 1);
        output[count_array[Array[i] - min] - 1] = Array[i];
        Print_Array(output, n, speed, debug, "Counting Sort", o, count_array[Array[i] - min] - 1);
        count_array[Array[i] - min]--;
    }

    for (int i = 0; i < n; i++) {// Copy the output array to Array,
        if (o == 1) {           // so that Array now contains sorted values
            Array[i] = output[i];
        }
        else {
            Array[i] = output[(n - 1) - i];
        }
    }
    Print_Array(output, n, speed, debug, "Counting Sort", o);
}
//********************************************//








//********************************************//
//                Radix Sort	             //
int getMax(int *arr, int n)
{
    int mx = arr[0];
    for (int i = 1; i < n; i++)
        if (arr[i] > mx)
            mx = arr[i];
    return mx;
}

void countSort(int *arr, int n, int exp)
{
    int *output = new int[n]; // output array
    int i, count[10] = { 0 };

    // Store count of occurrences in count[]
    for (i = 0; i < n; i++)
        count[(arr[i] / exp) % 10]++;

    // Change count[i] so that count[i] now contains actual
    //  position of this digit in output[]
    for (i = 1; i < 10; i++)
        count[i] += count[i - 1];

    // Build the output array
    for (i = n - 1; i >= 0; i--) {
        output[count[(arr[i] / exp) % 10] - 1] = arr[i];
        count[(arr[i] / exp) % 10]--;
    }

    // Copy the output array to arr[], so that arr[] now
    // contains sorted numbers according to current digit
    for (i = 0; i < n; i++) {
        arr[i] = output[i];
    }
}

// The main function to that sorts arr[] of size n using
// Radix Sort
void Radix(int *arr, int n, int o, int speed, int debug)
{
    // Find the maximum number to know number of digits
    int m = getMax(arr, n);

    // Do counting sort for every digit. Note that instead
    // of passing digit number, exp is passed. exp is 10^i
    // where i is current digit number
    for (int exp = 1; m / exp > 0; exp *= 10) {
        countSort(arr, n, exp);
        Print_Array(arr, n, speed, debug, "Radix Sort", o);
        TextColor(14);
        cout << "\nSorted by " << exp << "!";
        TextColor(15);
        Sleep(3000);
    }
    if (o == 2) {//If MAX->MIN, reverse the array
        int* temp = new int[n];
        int i;
        for (i = 0; i < n; i++) {
            temp[i] = arr[(n - 1) - i];
        }
        for (i = 0; i < n; i++) {
            arr[i] = temp[i];
        }
    }
}
//********************************************//







//********************************************//
//                 Heap Sort	             //
void heapify(int *arr, int n, int i, int o, int speed, int debug)
{
    int largest = i; // Initialize largest as root
    int l = 2 * i + 1; // left = 2*i + 1
    int r = 2 * i + 2; // right = 2*i + 2

    // If left child is larger than root
    if (l < n && arr[l] > arr[largest])
        largest = l;

    // If right child is larger than largest so far
    if (r < n && arr[r] > arr[largest])
        largest = r;

    // If largest is not root
    if (largest != i) {
        Print_Array(arr, n, speed, debug, "Heap Sort", o,i,largest);
        swap(arr[i], arr[largest]);
        Print_Array(arr, n, speed, debug, "Heap Sort", o,largest,i);
        // Recursively heapify the affected sub-tree
        heapify(arr, n, largest,o,speed,debug);
    }
}

// main function to do heap sort
void Heap(int* arr, int n, int o, int speed, int debug)
{
    // Build heap (rearrange array)
    for (int i = n / 2 - 1; i >= 0; i--) {
        heapify(arr, n, i,o,speed,debug);
    }
    // One by one extract an element from heap
    for (int i = n - 1; i > 0; i--) {
        // Move current root to end
        Print_Array(arr, n, speed, debug, "Heap Sort", o,0,i);
        swap(arr[0], arr[i]);
        Print_Array(arr, n, speed, debug, "Heap Sort", o,i,0);
        // call max heapify on the reduced heap
        heapify(arr, i, 0,o,speed,debug);
    }

    if (o == 2) {//If MAX->MIN, reverse the array
        int* temp = new int[n];
        int i;
        for (i = 0; i < n; i++) {
            temp[i] = arr[(n - 1) - i];
        }
        for (i = 0; i < n; i++) {
            arr[i] = temp[i];
        }
    }
    Print_Array(arr, n, speed, debug, "Heap Sort", o);
}
//********************************************//







//********************************************//
//                Quick Sort	             //
//MIN->MAX
void Quick1(int *a, int l, int r, int n, int speed, int debug) {
    int x = a[(l + r) / 2];
    int i = l;
    int j = r;
    int temp;
    //Move element to the right side
    while (j > i) {
        Print_Array(a, n, speed, debug, "Quick Sort", 1,i,j);
        while (a[i] < x) {//Check if element is on the right side
            i++;
            Print_Array(a, n, speed, debug, "Quick Sort", 1, i, j);
        }
        while (a[j] > x) {//Check if element is on the right side
            j--;
            Print_Array(a, n, speed, debug, "Quick Sort", 1, i, j);
        }
        if (j >= i) {//Swap two element that's on the wrong side
            Print_Array(a, n, speed, debug, "Quick Sort", 1, i, j);
            temp = a[i];
            a[i] = a[j];
            a[j] = temp;
            Print_Array(a, n, speed, debug, "Quick Sort", 1, j, i);
            i++; j--;
            Print_Array(a, n, speed, debug, "Quick Sort", 1, i, j);
        }
    }
    //Call QuickSort Again For The Two Side Arrays
    if (l < j)
        Quick1(a, l, j, n, speed, debug);
    if (r > i)
        Quick1(a, i, r, n, speed, debug);
}

//MAX->MIN
void Quick2(int* a, int l, int r, int n, int speed, int debug) {
    int x = a[(l + r) / 2];
    int i = l;
    int j = r;
    int temp;
    //Move element to the right side
    while (j > i) {
        Print_Array(a, n, speed, debug, "Quick Sort", 2, i, j);
        while (a[i] > x) {//Check if element is on the right side
            i++;
            Print_Array(a, n, speed, debug, "Quick Sort", 2, i, j);
        }
        while (a[j] < x) {//Check if element is on the right side
            j--;
            Print_Array(a, n, speed, debug, "Quick Sort", 2, i, j);
        }
        if (j >= i) {//Swap two element that's on the wrong side
            Print_Array(a, n, speed, debug, "Quick Sort", 2, i, j);
            temp = a[i];
            a[i] = a[j];
            a[j] = temp;
            Print_Array(a, n, speed, debug, "Quick Sort", 2, j, i);
            i++; j--;
            Print_Array(a, n, speed, debug, "Quick Sort", 2, i, j);
        }
    }
    //Call QuickSort Again For The Two Side Arrays
    if (l < j)
        Quick2(a, l, j, n, speed, debug);
    if (r > i)
        Quick2(a, i, r, n, speed, debug);
}
//********************************************//








//********************************************//
//                Merge Sort	             //
void merge1(int *arr, int l, int m, int r, int speed, int debug, int n)//Used for MIN->MAX
{
    int i, j, k;
    int n1 = m - l + 1;
    int n2 = r - m;

    //Create temp arrays
    int *L = new int[n1];
    int *R = new int[n2];

    //Copy data to temp arrays
    for (i = 0; i < n1; i++)
        L[i] = arr[l + i];
    for (j = 0; j < n2; j++)
        R[j] = arr[m + 1 + j];

    //Merge temp arrays into main array
    i = 0; // Init the begin position of the first subarray
    j = 0; // Init the begin position of the second subarray
    k = l; // Init the begin position of the result array
    while (i < n1 && j < n2)
    {
        Print_Array(arr, n, speed, debug, "Merge Sort", 1,k);
        if (L[i] <= R[j])
        {
            arr[k] = L[i];
            i++;
        }
        else
        {
            arr[k] = R[j];
            j++;
        }
        Print_Array(arr, n, speed, debug, "Merge Sort", 1,k);
        k++;
    }

    //Copy the left datas of L array to arr, if possible
    while (i < n1)
    {
        Print_Array(arr, n, speed, debug, "Merge Sort", 1, k);
        arr[k] = L[i];
        Print_Array(arr, n, speed, debug, "Merge Sort", 1, k);
        i++;
        k++;
    }

    //Copy the left datas of R array to arr, if possible
    while (j < n2)
    {
        Print_Array(arr, n, speed, debug, "Merge Sort", 1, k);
        arr[k] = R[j];
        Print_Array(arr, n, speed, debug, "Merge Sort", 1, k);
        j++;
        k++;
    }
    Print_Array(arr, n, speed, debug, "Merge Sort", 1);
}


void merge2(int *arr, int l, int m, int r, int speed, int debug, int n)//Used for MAX->MIN
{
    int i, j, k;
    int n1 = m - l + 1;
    int n2 = r - m;

    //Create temp arrays
    int* L = new int[n1];
    int *R = new int[n2];

    //Copy data to temp arrays
    for (i = 0; i < n1; i++)
        L[i] = arr[l + i];
    for (j = 0; j < n2; j++)
        R[j] = arr[m + 1 + j];

    //Merge temp arrays into main array
    i = 0; // Init the begin position of the first subarray
    j = 0; // Init the begin position of the second subarray
    k = l; // Init the begin position of the result array
    while (i < n1 && j < n2)
    {
        Print_Array(arr, n, speed, debug, "Merge Sort", 2, k);
        if (L[i] >= R[j])
        {      
            arr[k] = L[i];
            i++;
        }
        else
        {
            arr[k] = R[j];
            j++;
        }
        Print_Array(arr, n, speed, debug, "Merge Sort", 2, k);
        k++;
    }

    //Copy the left datas of L array to arr, if possible
    while (i < n1)
    {
        Print_Array(arr, n, speed, debug, "Merge Sort", 2, k);
        arr[k] = L[i];
        Print_Array(arr, n, speed, debug, "Merge Sort", 2, k);
        i++;
        k++;
    }

    //Copy the left datas of R array to arr, if possible
    while (j < n2)
    {
        Print_Array(arr, n, speed, debug, "Merge Sort", 2, k);
        arr[k] = R[j];
        Print_Array(arr, n, speed, debug, "Merge Sort", 2, k);
        j++;
        k++;
    }
    Print_Array(arr, n, speed, debug, "Merge Sort", 2);
}


void Merge(int *arr, int l, int r, int speed, int debug, int direction, int n) //l=0 r=n-1
{
    if (l < r)
    {
        int m = l + (r - l) / 2;
        int i=l;
        //Call mergeSort to devide array into two parts
        Merge(arr, l, m, speed, debug, direction,n);
        Merge(arr, m + 1, r, speed, debug, direction,n);

        if (direction == 1) {
            merge1(arr, l, m, r, speed, debug, n);
        }
        else {
            merge2(arr, l, m, r, speed, debug, n);
        }
    }
}
//********************************************//
