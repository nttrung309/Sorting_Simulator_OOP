#pragma once
#include "Sort.h"
#include "Func.h"
using namespace std;

class Array {
protected:
	int* Arr;
	int n;
public:
	Array() {
		Arr = new int[1000];
		n = 0;
	}
	Array(int temp[], int m) {
		Arr = new int[1000];
		this->n = m;
		int i;
		for (i = 0; i < m; i++)
		{
			Arr[i] = temp[i];
		}
	}
	Array(const Array& temp) {
		this->Arr = new int[1000];
		this->Arr = temp.Arr;
		this->n = temp.n;
	}
	void copy1(int a[], int m) {//Copy value of normal array
		this->n = m;
		int i;
		for (i = 0; i < m; i++)
		{
			Arr[i] = a[i];
		}
	}
	void copy2(int *a, int m) {//Copy value of pointer array
		this->n = m;
		int i;
		for (i = 0; i < m; i++)
		{
			Arr[i] = a[i];
		}
	}
	void self_copy(int a[], int& m) {//Copy value to array
		m = this->n;
		int i;
		for (i = 0; i < this->n; i++) {
			a[i] = this->Arr[i];
		}
	}
	void RandomArray()//Create random array
	{
		int ma, mi;
		cout << "\nEnter n: "; cin >> this->n;
		while (n < 1) {
			cout << "\nInvalid input!";
			cout << "\nEnter n: "; cin >> this->n;
		}
		cout << "Random Range:\n";
		cout << "Min= "; cin >> mi;
		cout << "Max= "; cin >> ma;
		srand((int)time(0));
		int i;
		for (i = 0; i < n; ++i)
		{
			Arr[i] = random(mi, ma);
		}
	}
	friend istream& operator>> (istream& is, Array& a) {
		cout << "\nEnter n: "; is >> a.n;
		while (a.n < 1) {
			cout << "\nInvalid input!";
			cout << "\nEnter n: "; cin >> a.n;
		}
		int i;
		for (i = 0; i < a.n; i++)
		{
			cout << "Element [" << i + 1 << "]: ";
			is >> a.Arr[i];
		}
		return is;
	}
	friend ostream& operator<< (ostream& os, Array a) {
		if (a.n != 0) {
			cout << "\n[";
			int i;
			for (i = 0; i < a.n; i++)
			{
				os << a.Arr[i];
				if (i != a.n - 1) {
					cout << ", ";
				}
			}
			cout << "]";
		}
		else {
			cout << "Rong!";
		}
		return os;
	}

	//DA HINH
	virtual void SelectionSort(int o, int s, int d) {}//o is direction, s is speed, d is debug
	virtual void InterchangeSort(int o, int s, int d){}
	virtual void InsertionSort(int o,int s, int d) {}
	virtual void BinaryInsertionSort(int o, int speed, int debug) {}
	virtual void BubbleSort(int o, int speed, int debug) {}
	virtual void ShakerSort(int o, int speed, int debug) {}
	virtual void ShellSort(int o, int speed, int debug) {}
	virtual void CountingSort(int o, int speed, int debug) {}
	virtual void RadixSort(int o, int speed, int debug) {}
	virtual void HeapSort(int o, int speed, int debug) {}
	virtual void QuickSort(int o, int speed, int debug) {}
	virtual void MergeSort(int o, int speed, int debug) {}
};



class Sort : public Array { //KE THUA
public:
	Sort() {}
	Sort(int temp[], int m) {
		Arr = new int[1000];
		this->n = m;
		int i;
		for (i = 0; i < m; i++)
		{
			Arr[i] = temp[i];
		}
	}
	void SelectionSort(int o, int s, int d) {
		if (o == 1) {
			Selection1(Arr, n, s, d);
		}
		else {
			Selection2(Arr, n, s, d);
		}
	}
	void InterchangeSort(int o, int s, int d) {//o is direction
		if (o == 1) {
			Interchange1(Arr, n, s, d);
		}
		else {
			Interchange2(Arr, n, s, d);
		}
	}
	void InsertionSort(int o,int speed, int debug) {
		if (o == 1) {
			Insertion1(Arr, n, speed, debug);
		}
		else {
			Insertion2(Arr, n, speed, debug);
		}
	}
	void BinaryInsertionSort(int o, int speed, int debug) {
		BinaryInsertion(Arr, n, o, speed, debug);
	}
	void BubbleSort(int o, int speed, int debug) {
		if (o == 1) {
			Bubble1(Arr, n, speed, debug);
		}
		else {
			Bubble2(Arr, n, speed, debug);
		}
	}
	void ShakerSort(int o, int speed, int debug) {
		if (o == 1) {
			Shaker1(Arr, n, speed, debug);
		}
		else {
			Shaker2(Arr, n, speed, debug);
		}
	}
	void ShellSort(int o, int speed, int debug) {
		if (o == 1) {
			Shell1(Arr, n, speed, debug);
		}
		else {
			Shell2(Arr, n, speed, debug);
		}
	}
	void CountingSort(int o, int speed, int debug) {
		Counting(Arr, n, o, speed, debug);
	}
	void RadixSort(int o, int speed, int debug) {
		Radix(Arr, n, o, speed, debug);
	}
	void HeapSort(int o, int speed, int debug) {
		Heap(Arr, n, o, speed, debug);
	}
	void QuickSort(int o, int speed, int debug) {
		if (o == 1) {
			Quick1(Arr, 0, n-1, n, speed, debug);
		}
		else {
			Quick2(Arr, 0, n-1, n, speed, debug);
		}
	}
	void MergeSort(int o, int speed, int debug) {
		Merge(Arr, 0, n - 1, speed, debug, o, n);
	}
};