#define _CRT_SECURE_NO_DEPRECATE
#include <iostream>
#include "Class.h"
#include "Func.h"

using namespace std;

int main()
{
	//Init Array//
	Array* a = new Sort;
	bool Exit = false;//To control the main loop
	int sort[5];//Way To Create Array, Sort Name, Direction, Speed, Process

	//Main Loop
	while (Exit == false) {//'Exit == True' means program finish, end loop

		//Create Array//
		system("cls");
		cout << "*******************************\n";
		cout << "_Sorting Algorithms Simulation_\n";
		cout << "*******************************\n\n";
		Print_Input();//Print Option
		cout << "\nYour choose: ";
		cin >> sort[0];
		while ((sort[0] < 0) or (sort[0] > 3)) {//Check if option is wrong!
			cout << "\nInvalid, please try again!";
			cout << "\nYour choose: ";
			cin >> sort[0];
		}
		switch (sort[0]) {//Process Options//
		case 1://Direct Input//
		{
			cout << "\nDIRECT INPUT:";
			cin >> *a;
			cout << *a;
			Sleep(2500);
			break;
		}
		case 2://Random Input//
		{
			cout << "\nRANDOM INPUT:";
			a->RandomArray();
			cout << *a;
			Sleep(2500);
			break;
		}
		case 3://Import From File//
		{
			cout << "\nFILE IMPORT:";
			int* temp = new int[1000];
			int n;
			getFile(temp, n);//Import array from file to a temp array
			a->copy2(temp, n);//Assign temp array to main array
			delete[] temp;
			cout << *a;
			Sleep(2500);
			break;
		}
		case 0:
		{
			cout << "\nGOOD BYE!";
			Exit = true;
			break;
		}
		}
		//Copy Main Array For Later Purpose
		int or_arr[1000];
		int n;
		a->self_copy(or_arr, n);//Copy main array to another array


		//Choose Sort Algorithm & Option
		if (Exit == false) {

			//Choose Sort
			system("cls");
			Print_Sort_List();//Print Sort List
			cout << "\nYour choose: ";
			cin >> sort[1];
			while ((sort[1] < 0) or (sort[1] > 12)) {//Check if option is wrong!
				cout << "\nInvalid, please try again!";
				cout << "\nYour choose: ";
				cin >> sort[0];
			}
			//Exit
			End(sort[1], Exit);//Check Exit!


			//Choose Direction
			if (Exit == false) {
				system("cls");
				Print_Direction();//Print Direction Choice
				cout << "\nYour choose: ";
				cin >> sort[2];
				while ((sort[2] < 0) or (sort[2] > 2)) {//Check if option is wrong!
					cout << "\nInvalid, please try again!";
					cout << "\nYour choose: ";
					cin >> sort[2];
				}
			}
			//Exit
			End(sort[2], Exit);//Check Exit!


			//Choose Speed
			if (Exit == false) {
				system("cls");
				Print_Speed();//Print Speed Choice
				cout << "\nYour choose: ";
				cin >> sort[3];
				while ((sort[3] < 0) or (sort[3] > 3)) {//Check if option is wrong!
					cout << "\nInvalid, please try again!";
					cout << "\nYour choose: ";
					cin >> sort[3];
				}
			}
			//Exit
			End(sort[3], Exit);//Check Exit!


			//Choose Process
			int pause;
			while (true) {//Loop For Pause Option
				if (Exit == false) {
					system("cls");
					Print_Process();//Print Process Option
					cout << "\nYour choose: ";
					cin >> sort[4];
					while ((sort[4] < 0) or (sort[4] > 4)) {//Check if option is wrong!
						cout << "\nInvalid, please try again!";
						cout << "\nYour choose: ";
						cin >> sort[4];
					}
				}
				//Exit
				End(sort[4], Exit);//Check Exit!

				//Pause Process
				if (sort[4] == 2) {//If Pause Chosen, Continue Loop
					system("cls");
					cout << "\nPaused";
					cout << "\n---------";
					cout << "\n1.Resume";
					cout << "\n0.Exit";
					cout << "\n---------";
					cout << "\nYour choose: ";
					cin >> pause;
					while ((pause > 1) or (pause < 0)) {//Check if option is wrong!
						cout << "\nInvalid, please try again!";
						cout << "\nYour choose: ";
						cin >> pause;
					}
					if (pause == 0) {//If pause==0, exit program, else go back to the process menu
						cout << "\nGOOD BYE!";
						Exit = true;
						break;
					}
				}
				else {//If pause wasn't chosen, break the loop
					break;
				}
			}



			//Call Sort
			if (Exit == false) {
				int cancel = 0;//If cancel was chosen, do not call sort function and go back to the start
				if (sort[4] == 3) {//Check if cancel was chosen
					cancel = 1;
				}
				if (cancel == 0) {//Cancel was't chosen, call sort function
					int debug = 0;
					if (sort[4] == 4) {//Check if debug was chosen
						debug = 1;
						system("cls");
					}
					switch (sort[1]) {//Switch to call the right algorithms, sort[1] store 'algorithms name'
					case 1://Selection Sort
					{
						if (debug) {
							Print_Debug(1,sort[2], sort[3]);
						}
						a->SelectionSort(sort[2], sort[3], debug);//sort[2] is direction, sort[3] is speed
						break;
					}
					case 2://Interchange Sort
					{
						if (debug) {
							Print_Debug(2, sort[2], sort[3]);
						}
						a->InterchangeSort(sort[2], sort[3], debug);//sort[2] is direction, sort[3] is speed
						break;
					}
					case 3://Insertion Sort
					{
						if (debug) {
							Print_Debug(3, sort[2], sort[3]);
						}
						a->InsertionSort(sort[2], sort[3], debug);//sort[2] is direction, sort[3] is speed
						break;
					}
					case 4://Binary Insersion Sort
					{
						if (debug) {
							Print_Debug(4, sort[2], sort[3]);
						}
						a->BinaryInsertionSort(sort[2], sort[3], debug);//sort[2] is direction, sort[3] is speed
						break;
					}
					case 5://Bubble Sort
					{
						if (debug) {
							Print_Debug(5, sort[2], sort[3]);
						}
						a->BubbleSort(sort[2], sort[3], debug);
						break;
					}
					case 6://Shaker Sort
					{
						if (debug) {
							Print_Debug(6, sort[2], sort[3]);
						}
						a->ShakerSort(sort[2], sort[3], debug);
						break;
					}
					case 7://Shell Sort
					{
						if (debug) {
							Print_Debug(7, sort[2], sort[3]);
						}
						a->ShellSort(sort[2], sort[3], debug);
						break;
					}
					case 8://Counting Sort
					{
						if (debug) {
							Print_Debug(8, sort[2], sort[3]);
						}
						a->CountingSort(sort[2], sort[3], debug);
						break;
					}
					case 9://Radix Sort
					{
						if (debug) {
							Print_Debug(9, sort[2], sort[3]);
						}
						a->RadixSort(sort[2], sort[3], debug);
						break;
					}
					case 10://Heap Sort
					{
						if (debug) {
							Print_Debug(10, sort[2], sort[3]);
						}
						a->HeapSort(sort[2], sort[3], debug);
						break;
					}
					case 11://Quick Sort
					{
						if (debug) {
							Print_Debug(11, sort[2], sort[3]);
						}
						a->QuickSort(sort[2], sort[3], debug);
						break;
					}
					case 12://Merge Sort
					{
						if (debug) {
							Print_Debug(12, sort[2], sort[3]);
						}
						a->MergeSort(sort[2], sort[3], debug);
						break;
					}
					}

					//Print Result
					cout << "\n\n\n\nDone!";
					cout << "\nOriginal Array:";
					Print_Array(or_arr, n);
					cout << "\n\nSorted Array: ";
					cout << *a;

					//Continue or Exit?
					cout << "\n\n------------";
					cout << "\n1.Continue";
					cout << "\n0.Exit";
					cout << "\n------------";
					int temp;
					cout << "\nYour Choose: ";
					cin >> temp;
					while ((temp > 1) or (temp < 0)) {//Check if option is wrong!
						cout << "\nInvalid, please try again!";
						cout << "\nYour choose: ";
						cin >> temp;
					}
					if (temp == 0) {//If temp==0, exit program, else continue
						cout << "\nGOOD BYE!";
						Exit = true;
					}
				}
			}
		}
	}
	return 0;
}