#pragma once
#include "Class.h"
#include <iostream>
#include <sstream>
#include <stdio.h>
#include <conio.h>
#include <windows.h>
using namespace std;

void TextColor(int x)//Change text color
{
    HANDLE mau;
    mau = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(mau, x);
}

void getFile(int* temp, int& n) {
    FILE* f;//Declare File Variable
    f = fopen("Array.txt", "a+");//Open file 'Array.txt' to read and append. If file doesn't exist, create new file!
    if (f != NULL) {//If open successfully / File exist
        char* a = new char[1000];//*char to read array
        fgets(a, 1000, f);//Read array to a
        fclose(f);//Close file
        string s(a);//Convert *char to string for easily process
        if (s.length() > 1) {
            int i;
            n = 0;
            int j = 0;
            string st = "";//Temp string to read EACH number
            for (i = 0; i <= int(s.length()); i++)
            {
                if ((s[i] >= 48) and (s[i] <= 57)) {//If s[i] is a number, append s[i] to string st
                    st += s[i];
                }
                else {//If s[i] is not a number(it's now a space), convert st to int and assign it to array
                    int num;
                    stringstream ss;
                    ss << st;
                    ss >> num;
                    temp[j] = num;
                    j++;
                    n = j;
                    st = "";
                }
            }
        }
        else {
            cout << "Empty File!";
        }
    }
    else {
        "There is no file!";
    }
}

int random(int min, int max)//Create random int value
{
    return min + rand() % (max + 1 - min);
}

void RandomArray(int* a, int n)//Create random array
{
    srand((int)time(0));
    int i;
    for (i = 0; i < n; ++i)
    {
        a[i] = random(1, 100);
    }
}

void Print_Input() {
    cout << "   Input Type";
    cout << "\n-----------------";
    cout << "\n1.Direct";
    cout << "\n2.Random";
    cout << "\n3.File(Array.txt)";
    cout << "\n0.Exit";
    cout << "\n-----------------";
}

void Print_Sort_List() {
    cout << "\n----------------";
    cout << "\n   SORT LIST  ";
    cout << "\n1.Selection Sort";
    cout << "\n2.Interchange Sort";
    cout << "\n3.Insertion Sort";
    cout << "\n4.Binary Insersion Sort";
    cout << "\n5.Bubble Sort";
    cout << "\n6.Shaker Sort";
    cout << "\n7.Shell Sort";
    cout << "\n8.Counting Sort";
    cout << "\n9.Radix Sort";
    cout << "\n10.Heap Sort";
    cout << "\n11.Quick Sort";
    cout << "\n12.Merge Sort";
    cout << "\n0.Exit";
    cout << "\n----------------";
}

void Print_Direction() {
    cout << "\nDirection";
    cout << "\n----------";
    cout << "\n1.Min->Max";
    cout << "\n2.Max->Min";
    cout << "\n0.Exit";
    cout << "\n----------";
}

void Print_Speed() {
    cout << "\n----------";
    cout << "\n Speed";
    cout << "\n1.Slow";
    cout << "\n2.Normal";
    cout << "\n3.Fast";
    cout << "\n0.Exit";
    cout << "\n----------";
}

void Print_Process() {
    cout << "\n----------";
    cout << "\n Process";
    cout << "\n1.Start";
    cout << "\n2.Pause";
    cout << "\n3.Cancel";
    cout << "\n4.Debug";
    cout << "\n0.Exit";
    cout << "\n----------";
 }

void End(int a,bool &Exit) {//Check Exit
    if (a == 0) {
        cout << "\nGOOD BYE!";
        Exit = true;
    }
}

void Speed_Process(int n, int speed, string name) {
    int level = 1;
    int k = 10;
    while (n > k) {
        level++;
        k += 10;
    }
    int sp=0;
    if (speed == 1) {
        sp = 1500;
    }
    if (speed == 2) {
        sp = 1000;
    }
    if (speed == 3) {
        sp = 800;
    }
    if((name!="Counting Sort") and (name!="Radix Sort"))
    while ((level != 1) and (sp>500)) {
        if ((sp - 200) > 500) {
            sp -= 200;
        }
        else {
            sp = 550;
            break;
        }
    }
    Sleep(sp);
    char pause;
    if (_kbhit()) {//Check if keyboard was hit
        pause = _getch();//Get the key that was hit
        if (pause == ' ') {//If key is Space, pause program
            cout << "\nPaused, press any key to continue!";
            pause = _getch();//Press any key to continue
        }
    }
}

void Print_Infor(int speed, int debug, string name, int direction) {
    if (debug == 0) {
        system("cls");
        cout << name;
        cout << "\nDirection: ";
        if (direction == 1) {
            cout << "MIN->MAX";
        }
        else {
            cout << "MAX->MIN";
        }
        cout << "\nSpeed: ";
        switch (speed) {
        case 1:
        {
            cout << "Slow";
            break;
        }
        case 2:
        {
            cout << "Normal";
            break;
        }
        case 3:
        {
            cout << "Fast";
            break;
        }
        }
        cout << "\nSorting...";
        cout << "\nPress Space to pause!\n";
    }
}

void Print_Array(int *a, int n, int speed, int debug, string name, int direction,int color1=-1, int color2=-1, int color3=-1) { //Print pointer array
    if (n != 0) {
        Print_Infor(speed,debug,name,direction);
        cout << "\n[";
        int i;
        for (i = 0; i < n; i++)
        {
            if (i == color1) {//Check if position need to be coloured
                TextColor(62);
            }
            if (i == color2) {
                TextColor(125);
            }
            if (i == color3) {
                TextColor(224);
            }
            cout << a[i];
            TextColor(15);
            if (i != n - 1) {
                cout << ", ";
            }
        }
        cout << "]";
    }
    if (name != "Radix Sort") {
        Speed_Process(n, speed, name);
    }
}

void Print_Array(int a[], int n) { //Print normal array
    if (n != 0) {
        cout << "\n[";
        int i;
        for (i = 0; i < n; i++)
        {
            cout << a[i];
            if (i != n - 1) {
                cout << ", ";
            }
        }
        cout << "]";
    }
}

void Print_Debug(int opt, int direction, int speed)
{
    switch (opt) {
        case 1:
            cout << "Selection Sort";
            break;
        case 2:
            cout << "Interchange Sort";
            break;
        case 3:
            cout << "Insertion Sort";
            break;
        case 4:
            cout << "Binary Insersion Sort";
            break;
        case 5:
            cout << "Bubble Sort";
            break;
        case 6:
            cout << "Shaker Sort";
            break;
        case 7:
            cout << "Shell Sort";
            break;
        case 8:
            cout << "Counting Sort";
            break;
        case 9:
            cout << "Radix Sort";
            break;
        case 10:
            cout << "Heap Sort";
            break;
        case 11:
            cout << "Quick Sort";
            break;
        case 12:
            cout << "Merge Sort";
            break;
    }

    cout << "\nDirection: ";
    if (direction == 1) {
        cout << "MIN->MAX";
    }
    else {
        cout << "MAX->MIN";
    }

    cout << "\nSpeed: ";
    switch (speed) {
    case 1:
    {
        cout << "Slow";
        break;
    }
    case 2:
    {
        cout << "Normal";
        break;
    }
    case 3:
    {
        cout << "Fast";
        break;
    }
    }
    cout << "\nDebugging...\n";
}





